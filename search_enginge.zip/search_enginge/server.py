# pip install Flask

from flask import Flask,request,jsonify,send_from_directory
from flask_cors import CORS
from core import search
app = Flask(__name__)
CORS(app)

@app.route("/")
def index():
    return send_from_directory('web','index.htm')

@app.route("/search", methods=["GET"])
def search_key():
    args = request.args
    key = args.get("key")
    data = search(key)
    return jsonify({"data": data})

if __name__ == "__main__":
    app.run()